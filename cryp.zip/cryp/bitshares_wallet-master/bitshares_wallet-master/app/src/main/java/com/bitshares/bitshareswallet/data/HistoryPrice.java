package com.bitshares.bitshareswallet.data;

import java.util.Date;

/**
 * Created by lorne on 03/11/2017.
 */
public class HistoryPrice {
    public double high;
    public double low;
    public double open;
    public double close;
    public double volume;
    public Date date;
}
