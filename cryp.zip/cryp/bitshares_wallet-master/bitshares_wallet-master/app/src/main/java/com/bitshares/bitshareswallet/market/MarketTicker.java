package com.bitshares.bitshareswallet.market;


public class MarketTicker {
    public String base;
    public String quote;
    public double latest;
    public double lowest_ask;
    public double highest_bid;
    public String percent_change;
    public double base_volume;
    public double quote_volume;
}
