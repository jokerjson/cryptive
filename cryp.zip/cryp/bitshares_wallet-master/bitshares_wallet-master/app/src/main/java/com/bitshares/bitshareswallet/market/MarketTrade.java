package com.bitshares.bitshareswallet.market;


import java.util.Date;


public class MarketTrade {
    public Date date;
    public double price;
    public double amount;
    public double value;
}
