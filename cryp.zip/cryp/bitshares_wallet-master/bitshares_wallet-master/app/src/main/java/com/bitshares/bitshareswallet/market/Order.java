package com.bitshares.bitshareswallet.market;


public class Order {
    public double price;
    public double quote;
    public double base;
}
