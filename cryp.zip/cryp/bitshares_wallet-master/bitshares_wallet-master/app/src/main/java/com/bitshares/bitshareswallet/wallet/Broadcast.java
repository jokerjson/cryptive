package com.bitshares.bitshareswallet.wallet;

public class Broadcast {
    /**
     * 货币类型更改
     */
    public static final String CURRENCY_UPDATED = "com.bitshares.bitshareswallet.wallet.CURRENCY_UPDATED";
}
