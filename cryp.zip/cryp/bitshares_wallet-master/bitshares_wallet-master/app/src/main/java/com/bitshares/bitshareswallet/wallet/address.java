package com.bitshares.bitshareswallet.wallet;


public class address {
}
