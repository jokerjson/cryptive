package com.bitshares.bitshareswallet.wallet.fc.impl;



public class static_variant<T> {
    int _tag;
}
