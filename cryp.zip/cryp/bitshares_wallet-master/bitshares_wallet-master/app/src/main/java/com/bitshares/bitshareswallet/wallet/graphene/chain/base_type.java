package com.bitshares.bitshareswallet.wallet.graphene.chain;

public class base_type {
}
