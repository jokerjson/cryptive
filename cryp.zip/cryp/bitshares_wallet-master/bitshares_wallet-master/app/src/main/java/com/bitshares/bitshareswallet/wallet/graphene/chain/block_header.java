package com.bitshares.bitshareswallet.wallet.graphene.chain;

import java.sql.Timestamp;
import java.util.Date;

public class block_header {
    String previous;  //block_id_type                 previous;
    public Date timestamp; // fc::time_point_sec            timestamp;
    //witness_id_type               witness;
    //checksum_type                 transaction_merkle_root;
    //extensions_type               extensions;

}
